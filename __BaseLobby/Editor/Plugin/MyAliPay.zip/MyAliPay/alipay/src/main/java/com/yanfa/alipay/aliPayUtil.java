package com.yanfa.alipay;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.unity3d.player.UnityPlayer;
import org.json.JSONObject;

import java.util.Map;

/**
 * Created by yanfa on 2017/1/12.
 */

public class aliPayUtil
{

    /** 支付宝支付业务：入参app_id */
    public static String APP_ID = "";


    /** 商户私钥，pkcs8格式 */
    /** 如下私钥，RSA2_PRIVATE 或者 RSA_PRIVATE 只需要填入一个 */
    /** 如果商户两个都设置了，优先使用 RSA2_PRIVATE */
    /** RSA2_PRIVATE 可以保证商户交易在更加安全的环境下进行，建议使用 RSA2_PRIVATE */
    /** 获取 RSA2_PRIVATE，建议使用支付宝提供的公私钥生成工具生成， */
    /** 工具地址：https://doc.open.alipay.com/docs/doc.htm?treeId=291&articleId=106097&docType=1 */
    public static final String RSA2_PRIVATE = "";
    public static final String RSA_PRIVATE = "";


    public static String _GameObjectName;

    //支付请求
    public void Pay(String unityMsg)
    {
        try{
            Log.i("msp", "jun : ~~~~java~~~~~~~~~Pay~~~"+unityMsg);

            JSONObject jsonMsg = new JSONObject(unityMsg);

            _GameObjectName = jsonMsg.getString("callbackGameObject");

            Log.i("msp", "jun : ~~~~java~~~~~~~~~Pay~~~"+_GameObjectName);

            /**
             * 这里只是为了方便直接向商户展示支付宝的整个支付流程；所以Demo中加签过程直接放在客户端完成；
             * 真实App里，privateKey等数据严禁放在客户端，加签过程务必要放在服务端完成；
             * 防止商户私密数据泄露，造成不必要的资金损失，及面临各种安全风险；
             *
             * orderInfo的获取必须来自服务端；
             */
            //final String orderInfo = GetrderInfo();
            final String orderInfo = jsonMsg.getString("orderInfo");
            Log.i("msp", "jun : ~~~~java~~~~~~~orderInfo~~~"+orderInfo);


            Runnable payRunnable = new Runnable() {

                @Override
                public void run() {
                    PayTask alipay = new PayTask(UnityPlayer.currentActivity);
                    Map<String, String> result = alipay.payV2(orderInfo, true);
                    JSONObject jsonResult = new JSONObject(result);
                    Log.i("msp", "jun : ~~~~java~~~~~~~~~payV2result~~~"+jsonResult.toString());
                    SendUnityMessage(jsonResult.toString());
                }
            };

            Thread payThread = new Thread(payRunnable);
            payThread.start();
        }catch (Exception e)
        {
            Log.i("msp", "jun : ~~~~java~~~~~~~~~Pay~~Exception~"+e);

        }
    }
    //向Unity发送消息
    public void SendUnityMessage(String msg)
    {
        Log.i("msp", "jun : ~~~~java~~~~~~~~~SendUnityMessage~~~"+_GameObjectName);
        UnityPlayer.UnitySendMessage(_GameObjectName,"OnAliPayCallback",msg);
    }
    //orderInfo的获取加签过程
    public String GetrderInfo()
    {
        boolean rsa2 = (RSA2_PRIVATE.length() > 0);
        Map<String, String> params = OrderInfoUtil2_0.buildOrderParamMap(APP_ID, rsa2);
        String orderParam = OrderInfoUtil2_0.buildOrderParam(params);

        String privateKey = rsa2 ? RSA2_PRIVATE : RSA_PRIVATE;
        String sign = OrderInfoUtil2_0.getSign(params, privateKey, rsa2);
        String orderInfo = orderParam + "&" + sign;

        return orderInfo;
    }
    /**
     * get the sdk version. 获取SDK版本号
     *
     */
    public void getSDKVersion() {
        PayTask payTask = new PayTask(UnityPlayer.currentActivity);
        String version = payTask.getVersion();
    }
}
