package com.example.admin.myapplication;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
//    private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
//    private ListView mList;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_main);
////        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
////        setSupportActionBar(toolbar);
////
////        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
////        fab.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
//////                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//////                        .setAction("Action", null).show();
////            }
////        });
//
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.voice_recognition);
//        Button speakButton = (Button) findViewById(R.id.btn_speak);
//        mList = (ListView) findViewById(R.id.listView1);
//
//        PackageManager pm = getPackageManager();
//        List<ResolveInfo> activities = pm.queryIntentActivities(new Intent(
//                RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0);  //通过全局包管理器及特定intent，查找系统是否有语音识别的服务程序
//        if (activities.size() != 0) {
//            speakButton.setOnClickListener(this);   //如果存在该activity
//        } else {
//            speakButton.setEnabled(false);
//            speakButton.setText("Recognizer not present");    //否则将BUTTON显示值修改，并设置成不可选
//        }
//    }
//
//    public void onClick(View v) {    //OnClickListener中的要override的函数
//        if (v.getId() == R.id.btn_speak) {
//            startVoiceRecognitionActivity();
//        }
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    private void startVoiceRecognitionActivity() {
//        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
//        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
//                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
//        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
//                "Speech recognition demo");    //设置语音识别Intent调用的特定属性参数
//        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);   //启动一个要求有返回值的activity调用
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {  //该函数非接口内也非抽象函数，为何会Override？
//        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE
//                && resultCode == RESULT_OK) {
//            // Fill the list view with the strings the recognizer thought it
//            // could have heard
//            ArrayList<String> matches = data
//                    .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);  //解析存储识别返回的结果
//            mList.setAdapter(new ArrayAdapter<String>(this,
//                    android.R.layout.simple_list_item_1, matches));  //在listview中显示结果
//        }
//
//        super.onActivityResult(requestCode, resultCode, data);
//    }


    private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        final ProgressBar progressBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(progressBar);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
        WebView webView = new WebView(this);
        ll.addView(webView, params);
//        webView.setBackgroundColor(Color.BLUE);
        setContentView(ll);

        WebSettings settings = webView.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true); // 支持缩放
        settings.setDisplayZoomControls(false);
        settings.setBuiltInZoomControls(true);
        settings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(this, "Mobile");//声明一个javascript可以调用的对象 //Mobile声明为javascrip可以调用的一个对象,对象的值为代码中的this

        //覆盖WebView默认使用第三方或系统默认浏览器打开网页的行为，使网页用WebView打开
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                //返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
                view.loadUrl(url);
                Log.i("1", "=================================");
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
            }
        });

        webView.loadUrl("http://pay.game597.cn/account/reg_mobile/");
//        webView.loadUrl("http://pay.game597.cn/account/reg_mobile/");
//        webView.loadUrl("javascript:Mobile.OnClick_OK()");//调用javascript
    }



    @JavascriptInterface
    public void OnClick_OK(){
        Log.i("1","OnClick_OK");
    }


    public void Init(){
        //-----------------语音识别----------------
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.btn); // 识别按钮
        PackageManager pm = getPackageManager();
        List activities = pm.queryIntentActivities(new Intent(
//                RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0); // 本地识别程序
                RecognizerIntent.ACTION_WEB_SEARCH), 0); // 网络识别程序

        /*
         * 此处没有使用捕捉异常，而是检测是否有语音识别程序。
         * 也可以在startRecognizerActivity()方法中捕捉ActivityNotFoundException异常
         */
        if (activities.size() != 0) {
            btn.setOnClickListener(this);
        } else {
            // 若检测不到语音识别程序在本机安装，测将扭铵置灰
            btn.setEnabled(false);
            btn.setText("未检测到语音识别设备");
        }
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btn) {
            startRecognizerActivity();
        }
    }
    // 开始识别
    private void startRecognizerActivity() {
        // 通过Intent传递语音识别的模式，开启语音
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        // 语言模式和自由模式的语音识别
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        // 提示语音开始
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "开始语音");
//        intent.addFlags(Intent.Trans);
        // 开始语音识别
        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
        // 调出识别界面
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 回调获取从谷歌得到的数据
        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE
                && resultCode == RESULT_OK) {
            // 取得语音的字符
            ArrayList<String> results = data
                    .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String resultString = "";
            for (int i = 0; i < results.size(); i++) {
                resultString += results.get(i) + "\r\n";
            }
            Toast.makeText(this, resultString, Toast.LENGTH_SHORT).show();
        }
        // 语音识别后的回调，将识别的字串以Toast显示
        super.onActivityResult(requestCode, resultCode, data);
    }
}
