package net.sourceforge.simcpux.wxapi;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

/**
 * Created by admin on 29/07/2016.
 */
public class WebActivityController extends Activity {
    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        final ProgressBar progressBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(progressBar);

        webView = new WebView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
        ll.addView(webView, params);
        setContentView(ll);

        WebSettings settings = webView.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true); // 支持缩放
        if(android.os.Build.VERSION.SDK_INT >= 11){
            settings.setDisplayZoomControls(false);
        }
        settings.setBuiltInZoomControls(true);
        settings.setJavaScriptEnabled(true);


        webView.addJavascriptInterface(this, "Mobile");//声明一个javascript可以调用的对象 //Mobile声明为javascrip可以调用的一个对象,对象的值为代码中的this

        //覆盖WebView默认使用第三方或系统默认浏览器打开网页的行为，使网页用WebView打开
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                //返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
                view.loadUrl(url);
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
            }
        });
        webView.loadUrl(WeChatPayUtil.WebActivity_URL);
//        webView.loadUrl("javascript:Mobile.OnClick_OK()");//调用javascript
    }

    @JavascriptInterface
    public void OnClick_OK(){
        finish();
    }
}