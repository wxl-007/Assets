package jqnn.u.lobby597lua.wxapi;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;

import net.sourceforge.simcpux.wxapi.WeChatPayUtil;


public class WXEntryActivity extends Activity implements IWXAPIEventHandler {
	
	private static final String TAG = "WXPayEntryActivity";
	
    private IWXAPI api;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.e("1","a--------------");
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.pay_result);
    	api = WXAPIFactory.createWXAPI(this, WeChatPayUtil.APP_ID);
        api.handleIntent(getIntent(), this);
    }

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		setIntent(intent);
        api.handleIntent(intent, this);
	}

	@Override
	public void onReq(BaseReq req) {
        Log.e("1","onreq openid = " + req.openId);
	}

	@Override
	public void onResp(BaseResp resp) {
		Log.e("1", "on SendAuth Finish, 597, errCode = " + resp.errCode);

		if (resp.getType() == ConstantsAPI.COMMAND_SENDAUTH) {
            SendAuth.Resp sendAuthResp = (SendAuth.Resp)resp;
			UnityPlayer.UnitySendMessage(WeChatPayUtil._GameObjectName, WeChatPayUtil.OnWechatSendAuthCallback, resp.errCode + ","+sendAuthResp.code);
			if(resp.errCode != 0) {
				AlertDialog.Builder builder = new AlertDialog.Builder(WeChatPayUtil._ContextActivity);
				builder.setTitle("提示");
				builder.setMessage("微信授权结果 : " + resp.errCode + ", 错误信息 : " + resp.errStr);
				builder.show();
			}
		}

		if (resp.getType() == ConstantsAPI.COMMAND_SENDMESSAGE_TO_WX) {
//			SendMessageToWX.Resp sendMsgResp = (SendMessageToWX.Resp)resp;
			UnityPlayer.UnitySendMessage(WeChatPayUtil._GameObjectName, WeChatPayUtil.OnWechatSendWebCallback, resp.errCode + "");
			if(resp.errCode != 0) {
				AlertDialog.Builder builder = new AlertDialog.Builder(WeChatPayUtil._ContextActivity);
				builder.setTitle("提示");
				builder.setMessage("微信分享结果 : " + resp.errCode + ", 错误信息 : " + resp.errStr);
				builder.show();
			}
		}

		WeChatPayUtil._ContextActivity = null;
		this.finish();
	}
}