package net.sourceforge.simcpux.wxapi;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.modelmsg.SendMessageToWX;
import com.tencent.mm.sdk.modelmsg.WXMediaMessage;
import com.tencent.mm.sdk.modelmsg.WXWebpageObject;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;

import org.json.JSONObject;


/**
 * Created by admin on 2/19/16.
 */
public class WeChatPayUtil implements Handler.Callback {

    public final static String OnWechatPayCallback = "OnWechatPayCallback";
    public final static String OnWechatSendAuthCallback = "OnWechatSendAuthCallback";
    public final static String OnWechatSendWebCallback = "OnWechatSendWebCallback";
    public static String APP_ID = "wxd930ea5d5a258f4f";
    public static String _GameObjectName;
    public static Activity _ContextActivity;
    public static String WebActivity_URL = "www.baidu.com";
    private static final int TIMELINE_SUPPORTED_VERSION = 0x21020001;
//    public static String _Url = "";

    public void Pay(String unityMsg){

        Message msg = new Message();
            msg.what = 1;
            msg.obj = unityMsg;
            UIHandler.sendMessage(msg, this);
    }

    public void SendAuth(String unityMsg){

        Message msg = new Message();
        msg.what = 2;
        msg.obj = unityMsg;
        UIHandler.sendMessage(msg, this);
    }

    public void SendWeb(String unityMsg){

        Message msg = new Message();
        msg.what = 3;
        msg.obj = unityMsg;
        UIHandler.sendMessage(msg, this);
    }

    public void OnClick_WebActivity(String url){
        Message msg = new Message();
        msg.what = 4;
        msg.obj = url;
        UIHandler.sendMessage(msg, this);
    }

    @Override
    public boolean handleMessage(Message msg) {

        _ContextActivity = UnityPlayer.currentActivity;
        Context context = UnityPlayer.currentActivity.getApplicationContext();

//        Toast.makeText(context, "获取订单中...", Toast.LENGTH_SHORT).show();
        if(msg.what == 1) return DoPay(msg, context);
        if(msg.what == 2) return DoSendAuth(msg,context);
        if(msg.what == 3) return DoSendWeb(msg,context);
        if(msg.what == 4) return Do_WebActivity(msg,context);

        return false;
    }

    private boolean DoPay(Message msg, Context context) {
        try{
                String content = (String)msg.obj;
//                Log.e("1", "get server pay params : " + content + ", context = " + context);
                JSONObject json = new JSONObject(content);
//            Log.e("1", "json = " + json);

            _GameObjectName = json.getString("callbackGameObject");
//            Log.e("1", "_GameObjectName =  " + _GameObjectName);
            APP_ID = json.getString("wxappid");//用于注册到微信的appid
            Log.e("1", "app_id =  " + APP_ID);
            IWXAPI api = WXAPIFactory.createWXAPI(context, APP_ID);

            if(!api.isWXAppInstalled() || !api.isWXAppSupportAPI()){
                Toast.makeText(context, "请安装最新版本微信", Toast.LENGTH_SHORT).show();
                UnityPlayer.UnitySendMessage(WeChatPayUtil._GameObjectName, OnWechatPayCallback, "-2");
                return false;
            }

//            Log.e("1", "api =  " + api);
            api.registerApp(APP_ID);

//            Log.e("1", "1 ");

                if(null != json && !json.has("retcode") ){
                    PayReq req = new PayReq();
                    //req.appId = "wxf8b4f85f3a794e77";  // 测试用appId
//                    Log.e("1", "2 ");
                    req.appId			= json.getString("appid");//从服务端返回的appid
                    req.partnerId		= json.getString("partnerid");
//                    Log.e("1", "3 ");
                    req.prepayId		= json.getString("prepayid");
                    req.nonceStr		= json.getString("noncestr");
                    req.timeStamp		= json.getString("timestamp");
//                    Log.e("1", "4 ");
                    req.packageValue	= json.getString("package");
                    req.sign			= json.getString("sign");
                    req.extData			= "app data"; // optional
                    Toast.makeText(context, "正常调起支付", Toast.LENGTH_SHORT).show();
                    // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
                    api.sendReq(req);
//                    Log.e("1", "PAY_GET : sendReq : ");
                }else{
                    Log.e("1", "PAY_GET : 返回错误" + json.getString("retmsg"));
                    Toast.makeText(context, "返回错误"+json.getString("retmsg"), Toast.LENGTH_SHORT).show();
                }
        }catch(Exception e){
            Log.e("1", "PAY_GET : 异常："+e.getMessage());
            Toast.makeText(context, "异常："+e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return false;
    }

    private boolean DoSendAuth(Message msg, Context context){
        try{
            String content = (String)msg.obj;
//            Log.e("1", "get server pay params : " + content + ", context = " + context);
            JSONObject json = new JSONObject(content);
//            Log.e("1", "json = " + json);

            _GameObjectName = json.getString("callbackGameObject");
            Log.e("1", "_GameObjectName =  " + _GameObjectName);
            APP_ID = json.getString("wxappid");//用于注册到微信的appid
//            Log.e("1", "app_id =  " + APP_ID);
            IWXAPI api = WXAPIFactory.createWXAPI(context, APP_ID);

            if(!api.isWXAppInstalled() || !api.isWXAppSupportAPI()){
                Toast.makeText(context, "请安装最新版本微信", Toast.LENGTH_SHORT).show();
                UnityPlayer.UnitySendMessage(WeChatPayUtil._GameObjectName, OnWechatSendAuthCallback, "-2");
                return false;
            }

            api.registerApp(APP_ID);

            SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = "WXSendAuth";
//            req.openId = "";

            api.sendReq(req);

        }catch(Exception e){
            Log.e("1", "SendAuth : 异常："+e.getMessage());
            Toast.makeText(context, "异常："+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    private boolean DoSendWeb(Message msg, Context context){
        try{
            String content = (String)msg.obj;
//            Log.e("1", "get server pay params : " + content + ", context = " + context);
            JSONObject json = new JSONObject(content);
//            Log.e("1", "json = " + json);

            _GameObjectName = json.getString("callbackGameObject");
            Log.e("1", "_GameObjectName =  " + _GameObjectName);
            APP_ID = json.getString("wxappid");//用于注册到微信的appid
//            Log.e("1", "app_id =  " + APP_ID);
            IWXAPI api = WXAPIFactory.createWXAPI(context, APP_ID);

            if(!api.isWXAppInstalled() || !api.isWXAppSupportAPI()){
                Toast.makeText(context, "请安装最新版本微信", Toast.LENGTH_SHORT).show();
                UnityPlayer.UnitySendMessage(WeChatPayUtil._GameObjectName, OnWechatSendWebCallback, "-2");
                return false;
            }

            api.registerApp(APP_ID);

            boolean isTimeline = json.getBoolean("isTimeline");
            if(isTimeline){
                int wxSdkVersion = api.getWXAppSupportAPI();
                if (wxSdkVersion < TIMELINE_SUPPORTED_VERSION) {
                    Toast.makeText(context, "请升级微信到最新版本", Toast.LENGTH_LONG).show();
                }
            }

            String title = json.getString("title");
            String url = json.getString("url");
            String description = json.getString("description");
            String imgPath = json.getString("imgPath");
//            String openId = json.getString("openId");

            WXWebpageObject webpage = new WXWebpageObject();
            webpage.webpageUrl = url;
            WXMediaMessage wxmsg = new WXMediaMessage(webpage);
            wxmsg.title = title;
            wxmsg.description = description;
            Bitmap thumb = BitmapFactory.decodeFile(imgPath); //GetIcon(); //BitmapFactory.decodeResource(_ContextActivity.getResources(),R.drawable.app_icon);
            wxmsg.thumbData = Util.bmpToByteArray(thumb, true);

            SendMessageToWX.Req req = new SendMessageToWX.Req();
            req.transaction = buildTransaction("webpage");
            req.message = wxmsg;
            req.scene = isTimeline ? SendMessageToWX.Req.WXSceneTimeline : SendMessageToWX.Req.WXSceneSession;
//            req.openId = "";
            api.sendReq(req);
            Log.e("1", "url = " + url);

        }catch(Exception e){
            Log.e("1", "DoSendWeb : 异常："+e.getMessage());
            Toast.makeText(context, "异常："+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    //该方法用于调用系统 WebView,与微信无关
    private boolean Do_WebActivity(Message msg, Context context){
        String content = (String)msg.obj;
        WebActivity_URL = content;

        //跳转到加载web的Activity
        _ContextActivity.startActivity(new Intent(_ContextActivity,WebActivityController.class));

        return false;
    }



    //-------------------辅助方法区------------------

    private String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }

    private Bitmap GetIcon(){
        PackageManager packageManager = null;
        ApplicationInfo applicationInfo = null;
        try {
            packageManager = _ContextActivity.getApplicationContext()
                    .getPackageManager();
            applicationInfo = packageManager.getApplicationInfo(
                    _ContextActivity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            applicationInfo = null;
        }
        Drawable d=packageManager.getApplicationIcon(applicationInfo); //xxx根据自己的情况获取drawable
        BitmapDrawable bd = (BitmapDrawable) d;
        Bitmap bm = bd.getBitmap();
        return bm;
    }
}



//public class WeChatPayUtil implements Handler.Callback {
//
//    public static String APP_ID = "wxd930ea5d5a258f4f";
//    public static String _GameObjectName;
//    public static String _Url = "";
//
//    public void Pay(String unityMsg){
//        try{
//            JSONObject jsonMsg = new JSONObject(unityMsg);
//            _GameObjectName = jsonMsg.getString("callbackGameObject");
//            APP_ID = jsonMsg.getString("appId");
//            _Url = jsonMsg.getString("url");
//
//            Message msg = new Message();
//            msg.what = 1;
//            msg.obj = jsonMsg;
//            UIHandler.sendMessage(msg, this);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public boolean handleMessage(Message msg) {
//
//        if(msg.what != 1) return false;
//
//        String url = _Url;//"http://wxpay.weixin.qq.com/pub_v2/app/app_pay.php?plat=android";
//        Context context = UnityPlayer.currentActivity.getApplicationContext();
//
//        IWXAPI api = WXAPIFactory.createWXAPI(context, APP_ID);
////        IWXAPI api = WXAPIFactory.createWXAPI(context, "wxb4ba3c02aa476ea1");
//        api.registerApp(APP_ID);
//
//
//        Toast.makeText(context, "获取订单中...", Toast.LENGTH_SHORT).show();
//        try{
//            byte[] buf = Util.httpGet(url);
//            if (buf != null && buf.length > 0) {
//                String content = new String(buf);
//                Log.e("get server pay params:", content);
//                JSONObject json = new JSONObject(content);
//                if(null != json && !json.has("retcode") ){
//                    PayReq req = new PayReq();
//                    //req.appId = "wxf8b4f85f3a794e77";  // 测试用appId
//                    req.appId			= json.getString("appid");
//                    req.partnerId		= json.getString("partnerid");
//                    req.prepayId		= json.getString("prepayid");
//                    req.nonceStr		= json.getString("noncestr");
//                    req.timeStamp		= json.getString("timestamp");
//                    req.packageValue	= json.getString("package");
//                    req.sign			= json.getString("sign");
//                    req.extData			= "app data"; // optional
//                    Toast.makeText(context, "正常调起支付", Toast.LENGTH_SHORT).show();
//                    // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
//                    api.sendReq(req);
//                }else{
//                    Log.d("PAY_GET", "返回错误"+json.getString("retmsg"));
//                    Toast.makeText(context, "返回错误"+json.getString("retmsg"), Toast.LENGTH_SHORT).show();
//                }
//            }else{
//                Log.d("PAY_GET", "服务器请求错误");
//                Toast.makeText(context, "服务器请求错误", Toast.LENGTH_SHORT).show();
//            }
//        }catch(Exception e){
//            Log.e("PAY_GET", "异常："+e.getMessage());
//            Toast.makeText(context, "异常："+e.getMessage(), Toast.LENGTH_SHORT).show();
//        }
//
//        return false;
//    }
//}